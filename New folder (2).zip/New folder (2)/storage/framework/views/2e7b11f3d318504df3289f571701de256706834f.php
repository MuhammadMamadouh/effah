<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/dropify/dist/css/dropify.min.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    الإجابات المقترحة
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <form class="form" method="post" action="<?php echo e(route('suggestion.update',$answer->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>نص السؤال</label>
                                    <input data-validation="required" type="text" readonly id="ar_title" value="<?php echo e($question->content); ?>" class="form-control"/>
                                </div>
                            </div>

                        </div>  <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>نص الإجابة</label>
                                    <input data-validation="required" type="text"  name="ar_title" id="ar_title" value="<?php echo e($answer->content); ?>" class="form-control"/>
                                </div>
                            </div>

                        </div>




                        <div class="form-group m-t-40 row">
                            <div class="col-10 offset-md-2">
                                <input type="submit" class="btn btn-success form-control" value="<?php echo e(trans('main.Create')); ?>" name="submut"
                                       style="color:#fff; font-weight: 400; font-size: 20px">
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin/plugins/dropify/dist/js/dropify.min.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('.dropify').dropify();

        });
    </script>
    <script>
        $(document).ready(function () {


        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/suggestion/edit.blade.php ENDPATH**/ ?>