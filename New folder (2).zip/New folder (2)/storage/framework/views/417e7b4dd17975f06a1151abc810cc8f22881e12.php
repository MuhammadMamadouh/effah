<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    
<?php echo e(trans('main.main')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">



        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('providers.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-warning text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\Admin::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-edit"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.Admins')); ?>  </h6>

                    </div>
                </div>
            </a>

        </div>

        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('contacts.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-success text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\ContactUs::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-phone"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.Messages')); ?> </h6>

                    </div>
                </div>
            </a>

        </div>

        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('adminRates.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-danger text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\Rate::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-calendar"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.Rates')); ?> </h6>

                    </div>
                </div>
            </a>

        </div>
        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('adminRates.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-info text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\Category::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-binoculars"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.categories')); ?> </h6>

                    </div>
                </div>
            </a>

        </div>

    </div>
    <div class="row">



        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('cities.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-primary text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\City::where('country_id',1)->count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-book"></i></h6>
                        <h6 class="text-white" > المحافظات  </h6>

                    </div>
                </div>
            </a>

        </div>

        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('subcities.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-danger text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\SubCity::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-music"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.Cities')); ?> </h6>

                    </div>
                </div>
            </a>

        </div>

        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('universities.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-success text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\University::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-university"></i></h6>
                        <h6 class="text-white" >الجامعات </h6>

                    </div>
                </div>
            </a>

        </div>
        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('colleges.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-warning text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\College::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-address-book"></i></h6>
                        <h6 class="text-white" > الكليات </h6>

                    </div>
                </div>
            </a>

        </div>

    </div>
    <div class="row">



        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('schools.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-danger text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\School::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-school"></i></h6>
                        <h6 class="text-white" > المدارس  </h6>

                    </div>
                </div>
            </a>

        </div>

        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('contacts.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-primary text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\ContactUs::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-phone"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.Messages')); ?> </h6>

                    </div>
                </div>
            </a>

        </div>

        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('adminRates.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-danger text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\Rate::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-calendar"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.Rates')); ?> </h6>

                    </div>
                </div>
            </a>

        </div>
        <div class="col-md-6 col-lg-3 col-xlg-3">
            <a href="<?php echo e(route('adminRates.index')); ?>">
                <div class="card card-inverse card-info card-shadow">
                    <div class="box_dash bg-info text-center">
                        <h1 class="font-light text-white" id="daly_advertisement">
                            <?php echo e($count = \App\Models\Category::count()); ?>

                        </h1>
                        <h6 class="text-white"><i class="fa fa-binoculars"></i></h6>
                        <h6 class="text-white" > <?php echo e(trans('main.categories')); ?> </h6>

                    </div>
                </div>
            </a>

        </div>

    </div>



      




    </div>
    <div class="row">
        <!-- Column -->













    </div>





   



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function () {


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/home/dashborad.blade.php ENDPATH**/ ?>