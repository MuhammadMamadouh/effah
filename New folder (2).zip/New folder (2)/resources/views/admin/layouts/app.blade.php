@extends('admin.layouts.layout')

@section('header')
@endsection


@section('page-title')
    {{-- عنوان الصفحة --}}
@endsection


@section('page-create')
    {{-- اضافة زرار--}}
@endsection

@section('content')

@endsection

@section('footer')
    <script>
        $(document).ready(function () {


        });
    </script>
@endsection
