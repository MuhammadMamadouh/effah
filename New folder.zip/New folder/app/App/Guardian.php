<?php

namespace App\App;

use Illuminate\Database\Eloquent\Model;

class Guardian extends Model
{
    //
}
