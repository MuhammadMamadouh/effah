<header class="topbar">
    <nav class="navbar top-navbar navbar-toggleable-sm navbar-light">
        <!-- ============================================================== -->
        <!-- Logo -->
        <!-- ============================================================== -->
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>">
                <!-- Logo icon -->
                <b>
                    <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                    <!-- Dark Logo icon -->
                    <img src="<?php echo e(asset('upload'.'/'.$settings['logo'])); ?>" alt="homepage"
                         width="120px" height="70px"/>
                </b>
                <!--End Logo icon -->
                <!-- Logo text -->
            </a>
        </div>
        <!-- ============================================================== -->
        <!-- End Logo -->
        <!-- ============================================================== -->
        <div class="navbar-collapse">
            <!-- ============================================================== -->
            <!-- toggle and nav items -->
            <!-- ============================================================== -->

            <!-- ============================================================== -->
            <!-- User profile notification -->


            <!-- ============================================================== -->
            <ul class="navbar-nav my-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href=""
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="dropdown-menu dropdown-menu-right animated flipInY">
                        <ul class="dropdown-user">
                            <li>
                                <a href="<?php echo e(route('profile.edit',admin()->user()->id)); ?>">
                                    <?php echo e(trans('main.Profile_edit')); ?>

                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('admin/profile/password').'/'.admin()->user()->id); ?>">
                                    <?php echo e(trans('main.Profile_pass')); ?>

                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.logout')); ?>" class="dropdown-item"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <i class="fa fa-power-off"></i>  <?php echo e(trans('main.Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </div>
                </li>
            </ul>

        </div>
    </nav>
</header>
<?php /**PATH D:\my projects\effah\resources\views/admin/inc/navbar.blade.php ENDPATH**/ ?>