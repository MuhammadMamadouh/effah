<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>

الأسئلة
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    


    <a href="<?php echo e(route('question.create')); ?>" class="btn pull-right hidden-sm-down btn-success"><i class="mdi mdi-plus-circle"></i><?php echo e(trans('main.Create')); ?></a>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-block">
                        <h4 class="card-title"><?php echo e(trans('main.Export')); ?></h4>
                        <div class="table-responsive m-t-40">
                            <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">

                                <?php
                                $count=1;
                                ?>
                                <?php if($questions->count()!=null): ?>
                                    <thead>
                                    <tr>
                                        <th>
                                            #
                                        </th>

                                        <th class="">السؤال </th>
                                        <th class="">الجنس</th>
                                        <th class="">الترتيب</th>
                                        <th class="">التفعيل</th>



                                         <th class="text-right">
                                            نوع السؤال
                                        </th>  <th class="text-right">
                                          <?php echo e(trans('main.Edit')); ?>

                                        </th>
                                    </tr>
                                    </thead>
                                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td class=""> <?php echo e($count++); ?></td>
                                            <td class="" style="max-width: 30%"><?php echo e($country->content); ?></td>

                                            <td class=""><?php if($country->gender==0): ?><span class="badge badge-success">الجميع</span>
                                                <?php elseif($country->gender==1): ?><span class="badge badge-primary">للشباب</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">للفتيات</span>
                                                <?php endif; ?>
                                            </td>
                                         <td class="" style="max-width: 30%">
                                             <form style="display: inline" action="<?php echo e(route('question.order',$country->id)); ?>">
                                                 <?php echo method_field('PUT'); ?>
                                                 <?php echo csrf_field(); ?>
                                                  <input type="hidden" name="type" value="1">
                                                 <button type="submit" class="btn btn-sm btn-success">
                                                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-up" viewBox="0 0 16 16">
                                                         <path fill-rule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z"/>
                                                     </svg>
                                                 </button>
                                             </form>
                                             <form style="display: inline" action="<?php echo e(route('question.order',$country->id)); ?>">
                                                 <?php echo method_field('PUT'); ?>
                                                 <?php echo csrf_field(); ?>
                                                 <input type="hidden" name="type" value="-1">
                                                 <button type="submit" class="btn btn-sm btn-danger">
                                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-down" viewBox="0 0 16 16">
                                                 <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
                                             </svg>
                                                 </button>
                                             </form>
                                         </td>
                                            <td class="" style="max-width: 30%">
                                                <form style="display: inline" action="<?php echo e(route('question.active',$country->id)); ?>" >
                                                    <?php echo method_field("PUT"); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <?php if($country->is_active	==1): ?>
                                                        <button type="submit" class="btn btn-sm btn-danger">إيقاف</button>
                                                    <?php else: ?>
                                                        <button type="submit" class="btn btn-sm btn-success">تفعيل</button>
                                                    <?php endif; ?>
                                                </form>
                                            </td>



                                          
                                            <td class="text-right"><?php if($country->type==1): ?><span class="badge badge-success">نصي</span>
                                                <?php elseif($country->type==2): ?><span class="badge badge-primary">إختيار واحد</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">إختيار متعدد</span>
                                                <?php endif; ?>
                                            </td>
                                       <td class="text-right">
                                                <a class="btn btn-sm btn-warning "
                                                   href="<?php echo e(route('question.edit',$country->id)); ?>">
                                                    <i class="mdi mdi-account-settings"></i><?php echo e(trans('main.Edit')); ?>

                                                </a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                                    <?php echo e(trans('main.no_row')); ?>


                                <?php endif; ?>

                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function () {


        });
    </script>

    <!-- start - This is for export functionality only -->
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example23').DataTable({
                dom: 'Bfrtip',

                buttons: [
                    { extend: 'copy', text: '<?php echo e(trans('main.Copy')); ?>' },
                    { extend: 'excel', text: '<?php echo e(trans('main.Excel')); ?>' },
                    { extend: 'pdf', text: '<?php echo e(trans('main.PDF')); ?>' },
                    { extend: 'print', text: '<?php echo e(trans('main.Print')); ?>' }
                ],
                "language": {
                    "sProcessing":   "<?php echo e(trans('main.sProcessing')); ?>",
                    "sLengthMenu":   "<?php echo e(trans('main.sLengthMenu')); ?>",
                    "sZeroRecords":  "<?php echo e(trans('main.sZeroRecords')); ?>",
                    "sInfo":         "<?php echo e(trans('main.sInfo')); ?>",
                    "sInfoEmpty":    "<?php echo e(trans('main.sInfoEmpty')); ?>",
                    "sInfoFiltered": "<?php echo e(trans('main.sInfoFiltered')); ?>",
                    "sInfoPostFix":  "",
                    "sSearch":       "<?php echo e(trans('main.sSearch')); ?>:",
                    "sUrl":          "",
                    "oPaginate": {
                        "sFirst":    "<?php echo e(trans('main.sFirst')); ?>",
                        "sPrevious": "<?php echo e(trans('main.sPrevious')); ?>",
                        "sNext":     "<?php echo e(trans('main.sNext')); ?>",
                        "sLast":     "<?php echo e(trans('main.sLast')); ?>"
                    }
                }
            });
            //End
            $(document).on('click', '.delete', function () {
                var id = $(this).attr('id');
                console.log(id)
                swal({
                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                    text: "<?php echo e(trans('main.Message_warning')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "<?php echo e(trans('main.Delete')); ?>",
                    cancelButtonText: "<?php echo e(trans('main.Cancel')); ?>",
                    okButtonText: "<?php echo e(trans('main.Accept')); ?>",
                    closeOnConfirm: false
                }, function () {
                    console.log(id)
                    $.ajax({
                        url: '<?php echo e(route('question.delete')); ?>',
                        type: 'post',
                        data: {id: id},
                        success: function (data) {
                            console.log(data)
                            if (data.error==1) {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                                    text: "<?php echo e(trans('main.Message_fail')); ?>",
                                    type: "error",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                });
                            } else {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_congratulation')); ?>",
                                    text: "<?php echo e(trans('main.Message_success')); ?>",
                                    type: "success",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                }, function () {
                                    location.reload();
                                });
                            }
                        }
                    });
                });
            });


        });//end jquery
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/questions/index.blade.php ENDPATH**/ ?>