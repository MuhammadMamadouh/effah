<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/html5-editor/bootstrap-wysihtml5.css')); ?>" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    
    <?php echo e(trans('main.Payments')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content win-height">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                            aria-hidden="true">×</span></button>
                <strong>عذرا!</strong> حدث خطأ ما فى ادخال البيانات.
                <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(Session::has('msg')): ?>
            <div class="alert alert-success">
                <a class="close" data-dismiss="alert">×</a>
                <strong style="margin:auto"><?php echo Session::get('msg'); ?>!</strong>
            </div>
        <?php elseif(Session::has('alert')): ?>
            <div class="alert alert-danger">
                <a class="close" data-dismiss="alert">×</a>
                <strong style="margin:auto"><?php echo Session::get('alert'); ?>!</strong>
            </div>

        <?php endif; ?>
      


        <div class="container-fluid">
            <div class="panel">
                <div class="panel-heading"></div>

                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="DTable table table-striped  table-bordered" cellspacing="0" width="100%">
                            <thead>

                            <tr>
                                <th>#</th>
                                <th>اسم العميل</th>
                                <th>اسم البنك </th>
                                <th>صورة التحويل </th>
                                  <th>رقم الحساب  </th>
                                <th>المبلغ</th>
                                 <th> قبول</th>
                                <th>حذف</th>
                            </tr>

                            </thead>

                            <tbody>
<?php
 $cou=0;
 ?>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e(++$cou); ?></th>

                                    <td class="test">
                                        <?php echo e(Illuminate\Support\Str::limit($ad->user->name)); ?>

                                    </td>

                                    <td>
                                        <?php echo e(Illuminate\Support\Str::limit($ad->bank->name,20)); ?>

                                    </td>

                                    <td >
                                        <img style="max-width=30px;max-height=330px" src="<?php echo e(asset('/'.$ad->image)); ?>"
                                                                           class="img-responsive img-fancy">
                                    </td>
                                      <td>
                                        <?php echo e(Illuminate\Support\Str::limit($ad->number,20)); ?>

                                    </td>
                                    <td>
                                        <?php echo e(Illuminate\Support\Str::limit($ad->amount,20)); ?>

                                    </td>

                                    <td>
  <form action="<?php echo e(route('payments.update' , $ad->id)); ?>"method="post">
      <?php echo method_field('PUT'); ?>
     <?php echo csrf_field(); ?>

     <input type="hidden" name="method" value="PUT">

                                         <button type="submit"       class="btn btn-sm btn-primary" data-toggle="tooltip"
                                                data-placement="top" title="قبول التحويل"><i class="fa fa-eye"></i></button>
                                                </form>
                                    </td>
                                    <td class="">
                                        <button class="btn btn-sm btn-danger delete"
                                                id="<?php echo e($ad->id); ?>">
                                            <i class="fa fa-trash-alt"></i> <?php echo e(trans('main.Delete')); ?>

                                        </button>
                                    </td>


                                    



                                </tr>



                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                        
                    </div>

                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function () {


        });
    </script>

    <!-- start - This is for export functionality only -->
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example23').DataTable({
                dom: 'Bfrtip',

                buttons: [
                    { extend: 'copy', text: '<?php echo e(trans('main.Copy')); ?>' },
                    { extend: 'excel', text: '<?php echo e(trans('main.Excel')); ?>' },
                    { extend: 'pdf', text: '<?php echo e(trans('main.PDF')); ?>' },
                    { extend: 'print', text: '<?php echo e(trans('main.Print')); ?>' }
                ],
                "language": {
                    "sProcessing":   "<?php echo e(trans('main.sProcessing')); ?>",
                    "sLengthMenu":   "<?php echo e(trans('main.sLengthMenu')); ?>",
                    "sZeroRecords":  "<?php echo e(trans('main.sZeroRecords')); ?>",
                    "sInfo":         "<?php echo e(trans('main.sInfo')); ?>",
                    "sInfoEmpty":    "<?php echo e(trans('main.sInfoEmpty')); ?>",
                    "sInfoFiltered": "<?php echo e(trans('main.sInfoFiltered')); ?>",
                    "sInfoPostFix":  "",
                    "sSearch":       "<?php echo e(trans('main.sSearch')); ?>:",
                    "sUrl":          "",
                    "oPaginate": {
                        "sFirst":    "<?php echo e(trans('main.sFirst')); ?>",
                        "sPrevious": "<?php echo e(trans('main.sPrevious')); ?>",
                        "sNext":     "<?php echo e(trans('main.sNext')); ?>",
                        "sLast":     "<?php echo e(trans('main.sLast')); ?>"
                    }
                }
            });
            //End
            $(document).on('click', '.delete', function () {
                var id = $(this).attr('id');
                console.log(id)
                swal({
                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                    text: "<?php echo e(trans('main.Message_warning')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "<?php echo e(trans('main.Delete')); ?>",
                    cancelButtonText: "<?php echo e(trans('main.Cancel')); ?>",
                    okButtonText: "<?php echo e(trans('main.Accept')); ?>",
                    closeOnConfirm: false
                }, function () {
                    console.log(id)
                    $.ajax({
                        url: '<?php echo e(route('payments.delete')); ?>',
                        type: 'post',
                        data: {id: id},
                        success: function (data) {
                            console.log(data)
                            if (data.error==1) {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                                    text: "<?php echo e(trans('main.Message_fail')); ?>",
                                    type: "error",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                });
                            } else {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_congratulation')); ?>",
                                    text: "<?php echo e(trans('main.Message_success')); ?>",
                                    type: "success",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                }, function () {
                                    location.reload();
                                });
                            }
                        }
                    });
                });
            });


        });//end jquery
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/pyments/newCharge.blade.php ENDPATH**/ ?>