<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    
    <?php echo e(trans('main.Users')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <h4 class="card-title"><?php echo e(trans('main.Export')); ?></h4>
                    <div class="table-responsive m-t-40">
                        <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">

                            <?php
                            $count=1;
                            ?>
                            <?php if($users->count()!=null): ?>
                                <thead>
                                <tr>
                                    <th>
                                        #
                                    </th>

                                    <th class=""><?php echo e(trans('main.User_name')); ?> </th>
                                    <th class="">الاسم  الثاني </th>
                                    <th class="">النوع </th>
                                    <th class=""><?php echo e(trans('main.mobile')); ?> </th>
                                    <th class=""><?php echo e(trans('main.Admin_image')); ?></th>

                                    <th class="">التحكم</th>



                                </tr>
                                </thead>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td class=""> <?php echo e($count++); ?></td>
                                        <td class=""><?php echo e($admin->frName); ?></td>
                                        <td class=""><?php if($admin->lsName): ?><?php echo e($admin->lsName); ?><?php else: ?> غير محدد <?php endif; ?> </td>
                                        <td class="">
                                            <?php if($admin->gender==1): ?><span class="badge badge-primary">شاب</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">فتاة</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class=""><?php echo e($admin->phone); ?></td>

                                        <td class="">
                                            <?php if($admin->image): ?>
                                            <img src="<?php echo e(asset('/'.$admin->image)); ?>" width="50px" height="50px">
                                                <?php else: ?>
                                                <span style="color: #9d0d0d" > لم يحدد صورة شخصية</span>

                                                <?php endif; ?>
                                        </td><td class="">
                                            <a href="<?php echo e(route('users.active',$admin->id)); ?>" class="btn btn-success  btn-sm"  style="padding: 10px">

                                                <?php if($admin->is_block==0): ?>
                                                    ايقاف
                                                <?php else: ?>
                                                    تفعيل
                                                <?php endif; ?>
                                                <i class="mdi mdi-account-tie"></i>
                                            </a>
                                        </td>
                                      


                                        
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>

                                <?php echo e(trans('main.no_row')); ?>


                            <?php endif; ?>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function () {


        });
    </script>

    <!-- start - This is for export functionality only -->
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example23').DataTable({
                dom: 'Bfrtip',

                buttons: [
                    { extend: 'copy', text: '<?php echo e(trans('main.Copy')); ?>' },
                    { extend: 'excel', text: '<?php echo e(trans('main.Excel')); ?>' },
                    { extend: 'pdf', text: '<?php echo e(trans('main.PDF')); ?>' },
                    { extend: 'print', text: '<?php echo e(trans('main.Print')); ?>' }
                ],
                "language": {
                    "sProcessing":   "<?php echo e(trans('main.sProcessing')); ?>",
                    "sLengthMenu":   "<?php echo e(trans('main.sLengthMenu')); ?>",
                    "sZeroRecords":  "<?php echo e(trans('main.sZeroRecords')); ?>",
                    "sInfo":         "<?php echo e(trans('main.sInfo')); ?>",
                    "sInfoEmpty":    "<?php echo e(trans('main.sInfoEmpty')); ?>",
                    "sInfoFiltered": "<?php echo e(trans('main.sInfoFiltered')); ?>",
                    "sInfoPostFix":  "",
                    "sSearch":       "<?php echo e(trans('main.sSearch')); ?>:",
                    "sUrl":          "",
                    "oPaginate": {
                        "sFirst":    "<?php echo e(trans('main.sFirst')); ?>",
                        "sPrevious": "<?php echo e(trans('main.sPrevious')); ?>",
                        "sNext":     "<?php echo e(trans('main.sNext')); ?>",
                        "sLast":     "<?php echo e(trans('main.sLast')); ?>"
                    }
                }
            });

            //End
            $(document).on('click', '.delete', function () {
                var id = $(this).attr('id');
                console.log(id)
                swal({
                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                    text: "<?php echo e(trans('main.Message_warning')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "<?php echo e(trans('main.Delete')); ?>",
                    cancelButtonText: "<?php echo e(trans('main.Cancel')); ?>",
                    okButtonText: "<?php echo e(trans('main.Accept')); ?>",
                    closeOnConfirm: false
                }, function () {
                    console.log(id)
                    $.ajax({
                        url: '#',
                        type: 'post',
                        data: {id: id},
                        success: function (data) {
                            console.log(data)
                            if (data.error==1) {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                                    text: "<?php echo e(trans('main.Message_fail')); ?>",
                                    type: "error",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                });
                            } else {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_congratulation')); ?>",
                                    text: "<?php echo e(trans('main.Message_success')); ?>",
                                    type: "success",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                }, function () {
                                    location.reload();
                                });
                            }
                        }
                    });
                });
            });


        });//end jquery
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/users/index.blade.php ENDPATH**/ ?>