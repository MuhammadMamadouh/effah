<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    
    المحافظات<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <form class="form" method="post" action="<?php echo e(route('cities.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>اسم المحافظة  باللغة العربية</label>
                                    <input data-validation="required" type="text"  name="ar_title" id="ar_title" value="<?php echo e(old('ar_title')); ?>" class="form-control"/>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>اسم المحافظة  باللغة الانجليزية</label>
                                    <input data-validation="required" type="text"  name="en_title" id="en_title" value="<?php echo e(old('en_title')); ?>" class="form-control"/>
                                </div>
                            </div>

                        </div>


                        <div class="form-group m-t-40 row <?php $__errorArgs = ['en_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="name-ar" class="col-2 col-form-label">الدولة<span
                                    class="text-danger">*</span></label>
                            <div class="col-10">
                                <select name="country_id"  class="form-control">
                                    <option selected disabled value="">  إختر الدولة</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=" <?php echo e($country->id); ?>">  <?php echo e($country->ar_title); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['en_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="form-control-feedback"> </small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group m-t-40 row">
                            <div class="col-10 offset-md-2">
                                <input type="submit" class="btn btn-success form-control" value="<?php echo e(trans('main.Create')); ?>" name="submut"
                                       style="color:#fff; font-weight: 400; font-size: 20px">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function () {


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/cities/create.blade.php ENDPATH**/ ?>