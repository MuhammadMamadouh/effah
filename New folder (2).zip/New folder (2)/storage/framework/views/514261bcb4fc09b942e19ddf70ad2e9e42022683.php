
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- User profile -->
        <div class="user-profile">
            <!-- User profile image -->
            <div class="profile-img"><img src="<?php echo e(admin()->user()->image!=null?asset('upload').'/'.admin()->user()->image:asset('admin/images/admin-avatar.png')); ?>" alt="user"/></div>
            <!-- User profile text-->
            <div class="profile-text">
                <a href="#" class="dropdown-toggle link u-dropdown" data-toggle="dropdown"
                                         role="button" aria-haspopup="true"
                                         aria-expanded="true"><?php echo e(Auth::guard('admin')->user()->name); ?> <span
                            class="caret"></span>
                </a>
                <div class="dropdown-menu animated flipInY">
                    <a href="<?php echo e(route('admin.logout')); ?>" class="link" data-toggle="tooltip" title="تسجيل خروج">


                        <i class="mdi mdi-power">تسجيل خروج</i>


                    </a>

                </div>
            </div>
        </div>
        <!-- End User profile text-->
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li><a href="<?php echo e(route('home.index')); ?>"><i class="mdi mdi-gauge"></i><span class="hide-menu"><?php echo e(trans('main.main')); ?></span></a></li>


                <li><a href="<?php echo e(route('theme.index')); ?>"><i class="fa fa-coffee"></i><span class="hide-menu"><?php echo e(trans('main.ColorsController')); ?></span></a></li>



                <li><a href="<?php echo e(route('choseCountry.index')); ?>"><i class="fa fa-flag"></i><span class="hide-menu">إختر الدين</span></a></li>

                <li><a href="<?php echo e(route('setting.index')); ?>"><i class="mdi mdi-settings"></i><span class="hide-menu"><?php echo e(trans('main.Setting')); ?></span></a></li>
                <li><a href="<?php echo e(route('admins.index')); ?>"><i class="mdi mdi-contrast-box"></i><span class="hide-menu"><?php echo e(trans('main.Admins')); ?></span></a></li>
                <li><a href="<?php echo e(route('categories.index')); ?>"><i class=" fa fa-caret-square-o-down"></i><span class="hide-menu"> <?php echo e(trans('main.Categories')); ?></span></a></li>
                <li><a href="<?php echo e(route('question.index')); ?>"><i class="fa fa-film"></i><span class="hide-menu"> الأسئلة</span></a></li>
                <li><a href="<?php echo e(route('answers.index')); ?>"><i class="fa fa-bars"></i><span class="hide-menu"> الإجابات</span></a></li>
                <li><a href="<?php echo e(route('suggestion.index')); ?>"><i class="fa fa-modx"></i><span class="hide-menu"> الإجابات المقترحة</span></a></li>

                <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-users"></i><span class="hide-menu"> <?php echo e(trans('main.Users')); ?></span></a></li>
                    <li><a href="<?php echo e(route('universities.index')); ?>"><i class="fa fa-address-book"></i><span class="hide-menu"> الجامعات</span></a></li>
                    <li><a href="<?php echo e(route('colleges.index')); ?>"><i class="fa fa-file-code-o"></i><span class="hide-menu"> الكليات</span></a></li>
                    <li><a href="<?php echo e(route('schools.index')); ?>"><i class="fa fa-sitemap"></i><span class="hide-menu"> </span> المدارس</a></li>
                    <li><a href="<?php echo e(route('careers.index')); ?>"><i class="fa fa-suitcase"></i><span class="hide-menu"> </span> المهن</a></li>

                <li><a href="<?php echo e(route('cities.index')); ?>"><i class="fa fa-book"></i><span class="hide-menu"> المحافظات</span></a></li>
                <li><a href="<?php echo e(route('subcities.index')); ?>"><i class="fa fa-university"></i><span class="hide-menu"> المدن</span></a></li>
                <li><a href="<?php echo e(route('bank.index')); ?>"><i class="fa fa-bullhorn"></i><span class="hide-menu"> <?php echo e(trans('main.BankAccounts')); ?></span></a></li>
                <li><a href="<?php echo e(route('payments.index')); ?>"><i class="fa fa-barcode"></i><span class="hide-menu"> <?php echo e(trans('main.Payments')); ?></span></a></li>

 <li><a href="<?php echo e(route('messages.index')); ?>"><i class="fa fa-envelope-o"></i><span class="hide-menu"> <?php echo e(trans('main.Messages')); ?> </span></a></li>


                <li><a href="<?php echo e(route('siteTexts.index')); ?>"><i class="fa fa-text-width"></i><span class="hide-menu"><?php echo e(trans('main.AboutApp')); ?></span></a></li>
                <li><a href="<?php echo e(route('contacts.index')); ?>"><i class="fa fa-phone-square"></i><span class="hide-menu"><?php echo e(trans('main.CallUs')); ?></span></a></li>




            </ul>

        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
    <!-- Bottom points-->
    <div class="sidebar-footer">
        <!-- item-->
        <a href="<?php echo e(route('setting.index')); ?>" class="link" data-toggle="tooltip" title="الاعدادت"><i class="ti-settings"></i></a>
        <!-- item-->

        <!-- item-->
        <a href="<?php echo e(route('admin.logout')); ?>" class="link" data-toggle="tooltip" title="تسجيل خروج">


            <i class="mdi mdi-power"></i>


        </a>
    </div>
    <!-- End Bottom points-->
</aside>


<?php /**PATH E:\new projects\effah\resources\views/admin/inc/sidebar.blade.php ENDPATH**/ ?>