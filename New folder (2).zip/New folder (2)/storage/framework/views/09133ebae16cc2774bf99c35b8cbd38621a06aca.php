<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    
   التحكم بالالوان
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <form class="form" method="post" action="<?php echo e(route('theme.update', Auth::guard('admin')->user()->id)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>


                        <div class="form-group m-t-40 row <?php $__errorArgs = ['en_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="name-ar" class="col-2 col-form-label">لون المظهر <span
                                    class="text-danger">*</span></label>
                            <div class="col-10">
                                <select name="them"  class="form-control">
                                    <option <?php if(admin()->user()->them==1): ?>selected <?php endif; ?> value="1"> الافتراضي</option>
                                    <option <?php if(admin()->user()->them==3): ?>selected <?php endif; ?> value="3">   ابيض في ازرق</option>
                                    <option <?php if(admin()->user()->them==2): ?>selected <?php endif; ?>  value="2"> ازرق في ابيض</option>
                                    <option <?php if(admin()->user()->them==4): ?>selected <?php endif; ?> value="4"> ابيض في اسود</option>
                                    <option <?php if(admin()->user()->them==5): ?>selected <?php endif; ?> value="5"> ابيض في اخضر</option>
                                    <option <?php if(admin()->user()->them==6): ?>selected <?php endif; ?> value="6"> اخضر في اسود</option>
                                    <option <?php if(admin()->user()->them==7): ?>selected <?php endif; ?> value="7">ابيض في  سماوي</option>
                                    <option  <?php if(admin()->user()->them==8): ?>selected <?php endif; ?> value="8"> سماوي في اسود</option>
                                    <option <?php if(admin()->user()->them==9): ?>selected <?php endif; ?> value="9">ابيض في  بنفسج</option>
                                    <option <?php if(admin()->user()->them==10): ?>selected <?php endif; ?> value="10"> بنفسج في اسود</option>
                                    <option <?php if(admin()->user()->them==11): ?>selected <?php endif; ?> value="11"> ابيض في احمر</option>
                                    <option <?php if(admin()->user()->them==12): ?>selected <?php endif; ?> value="12"> احمر في اسود</option>

                                </select>
                                <?php $__errorArgs = ['en_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="form-control-feedback"> </small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>




                        <div class="form-group m-t-40 row">
                            <div class="col-10 offset-md-2">
                                <input type="submit" class="btn btn-success form-control" value="<?php echo e(trans('main.Edit')); ?>" name="submut"
                                       style="color:#fff; font-weight: 400; font-size: 20px">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function () {


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\my projects\effah\resources\views/admin/theme/change.blade.php ENDPATH**/ ?>