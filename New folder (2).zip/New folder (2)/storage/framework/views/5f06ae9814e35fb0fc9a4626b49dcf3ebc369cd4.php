<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/dropify/dist/css/dropify.min.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    
    المهن<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <form class="forms-sample" method="post" action="<?php echo e(route('careers.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>اسم المهنة   </label>
                                    <input data-validation="required" type="text"  name="name" id="ar_title" value="<?php echo e(old('name')); ?>" class="form-control"/>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label> الجنس  </label>
                                    <select class="form-control" name="parent_id">

                                            <option value="0">الجنسين</option>
                                            <option value="1">الذكور</option>
                                            <option value="2">الإيناث</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                      



                        <button type="submit" class="btn btn-gradient-primary mr-2">إضافة</button>
                    </form>                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin/plugins/dropify/dist/js/dropify.min.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('.dropify').dropify();

        });
    </script>
    <script>
        $(document).ready(function () {


        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/careers/create.blade.php ENDPATH**/ ?>