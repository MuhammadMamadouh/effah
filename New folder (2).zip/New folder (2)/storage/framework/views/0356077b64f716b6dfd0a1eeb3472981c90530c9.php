<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
    
    التصنيفات
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-create'); ?>
    
    <a href="<?php echo e(route('categories.create')); ?>" class="btn pull-right hidden-sm-down btn-success"><i class="mdi mdi-plus-circle"></i><?php echo e(trans('main.Create')); ?></a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <h4 class="card-title"><?php echo e(trans('main.Export')); ?></h4>
                    <div class="table-responsive m-t-40">
                        <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">

                            <?php
                            $count=1;
                            ?>
                            <?php if($categories->count()!=null): ?>
                                <thead>
                                <tr>
                                    <th>
                                        #
                                    </th>

                                    <th class=""><?php echo e(trans('main.Name')); ?> </th>



                                    <th class="">
                                        <?php echo e(trans('main.Edit')); ?>

                                    </th>  <th class="">
                                        <?php echo e(trans('main.Delete')); ?>

                                    </th>

                                </tr>
                                </thead>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td class=""> <?php echo e($count++); ?></td>
                                        <td class=""> <?php echo e($c->name); ?></td>


                                        <td class="">
                                            <a class="btn btn-sm btn-warning "
                                               href="<?php echo e(route('categories.edit',$c->id)); ?>">
                                                <i class="mdi mdi-account-settings"></i><?php echo e(trans('main.Edit')); ?>

                                            </a>
                                        </td>

                                        <td class="">
                                            <button class="btn btn-sm btn-danger delete"
                                                    id="<?php echo e($c->id); ?>">
                                                <i class="fa fa-trash-alt"></i> <?php echo e(trans('main.Delete')); ?>

                                            </button>
                                        </td>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(trans('main.no_row')); ?>

                                </div>
                            <?php endif; ?>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $( document ).ready(function() {
            console.log( "ready!" );
        });
    </script>

    <!-- start - This is for export functionality only -->
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example23').DataTable({
                dom: 'Bfrtip',

                buttons: [
                    { extend: 'copy', text: '<?php echo e(trans('main.Copy')); ?>' },
                    { extend: 'excel', text: '<?php echo e(trans('main.Excel')); ?>' },
                    { extend: 'pdf', text: '<?php echo e(trans('main.PDF')); ?>' },
                    { extend: 'print', text: '<?php echo e(trans('main.Print')); ?>' }
                ],
                "language": {
                    "sProcessing":   "<?php echo e(trans('main.sProcessing')); ?>",
                    "sLengthMenu":   "<?php echo e(trans('main.sLengthMenu')); ?>",
                    "sZeroRecords":  "<?php echo e(trans('main.sZeroRecords')); ?>",
                    "sInfo":         "<?php echo e(trans('main.sInfo')); ?>",
                    "sInfoEmpty":    "<?php echo e(trans('main.sInfoEmpty')); ?>",
                    "sInfoFiltered": "<?php echo e(trans('main.sInfoFiltered')); ?>",
                    "sInfoPostFix":  "",
                    "sSearch":       "<?php echo e(trans('main.sSearch')); ?>:",
                    "sUrl":          "",
                    "oPaginate": {
                        "sFirst":    "<?php echo e(trans('main.sFirst')); ?>",
                        "sPrevious": "<?php echo e(trans('main.sPrevious')); ?>",
                        "sNext":     "<?php echo e(trans('main.sNext')); ?>",
                        "sLast":     "<?php echo e(trans('main.sLast')); ?>"
                    }
                }
            });

            //End
            $(document).on('click', '.delete', function () {
                var id = $(this).attr('id');
                console.log(id)
                swal({
                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                    text: "<?php echo e(trans('main.Message_warning')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "<?php echo e(trans('main.Delete')); ?>",
                    cancelButtonText: "<?php echo e(trans('main.Cancel')); ?>",
                    okButtonText: "<?php echo e(trans('main.Accept')); ?>",
                    closeOnConfirm: false
                }, function () {
                    console.log(id)
                    $.ajax({
                        url: '<?php echo e(route('categories.delete')); ?>',
                        type: 'post',
                        data: {id: id},
                        success: function (data) {
                            console.log(data)
                            if (data.error==1) {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                                    text: "<?php echo e(trans('main.Message_fail')); ?>",
                                    type: "error",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                });
                            } else {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_congratulation')); ?>",
                                    text: "<?php echo e(trans('main.Message_success')); ?>",
                                    type: "success",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                }, function () {
                                    location.reload();
                                });
                            }
                        }
                    });
                });
            });
            $(document).on('click', '.edit', function () {
                alert('hhh');
                var id = $(this).attr('id');
                console.log(id)
                swal({
                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                    text: "<?php echo e(trans('main.Message_warning')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "<?php echo e(trans('main.Edit')); ?>",
                    cancelButtonText: "<?php echo e(trans('main.Cancel')); ?>",
                    okButtonText: "<?php echo e(trans('main.Accept')); ?>",
                    closeOnConfirm: false
                }, function () {

                    console.log(id)
                    $.ajax({
                        url: '<?php echo e(url('admin/categories/')); ?>'+'/'+id+'<?php echo e(('/edit')); ?>',
                        type: 'get',
                        data: {id: id},
                        success: function (data) {
                            console.log(data)
                            if (data.error==1) {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_attention')); ?>",
                                    text: "<?php echo e(trans('main.Message_fail')); ?>",
                                    type: "error",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                });
                            } else {
                                swal({
                                    title: "<?php echo e(trans('main.Message_title_congratulation')); ?>",
                                    text: "<?php echo e(trans('main.Message_edit_success')); ?>",
                                    type: "success",
                                    confirmButtonText: "<?php echo e(trans('main.Accept')); ?>"
                                }, function () {
                                    var url= '<?php echo e(url('admin/admins/')); ?>'+'/'+id+'<?php echo e(('/edit')); ?>';

                                    window.location = url;
                                });
                            }
                        }
                    });
                });
            });


        });//end jquery
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\new projects\effah\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>